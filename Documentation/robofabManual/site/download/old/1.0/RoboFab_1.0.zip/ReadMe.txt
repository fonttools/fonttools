RoboFab Readme

Thanks for opening up the read me. The file contains some notes on installing Robofab, how to make documentation, python, dependencies on other packages.


v1.0b1 release October 6 2003
September 14, 2003
September 1, 2003
July 27, 2003

-------------------------------------------
Contents:
-------------------------------------------
	0.0 Which Python?
	0.2 Dependencies
	0.3 Documentation

	1.0 Installing on OSX, Unix, Python > 2.3b1
	1.1 Installing on OSX, MacPython "OS9" 2.3
	1.2 Installing on other platforms

	2.0 Testing

	3.0 Notes

	4.0 Contact the developers


-------------------------------------------
0.0 Which Python?
-------------------------------------------

On MacOS the Python version that will work with both FontLab and RoboFab is MacPython-OS9 2.3. Windows and other OS's: Python 2.3 

About install.py
In the package, on the same level as this read me there's a install.py script. Running this script creates a robofab.pth file to be created in site-packages. This robofab.pth file contains the path to the current location of the robofab package. It does not copy the robofab package to site-packages itself, you need to keep the robofab package. Also: it you _move_ the RoboFab folder, you have to run the install.py script again.

Download Python
http://www.python.org/download

MacOS Python download page:
http://homepages.cwi.nl/~jack/macpython/download.html


-------------------------------------------
0.2 Dependencies
-------------------------------------------
Robofab requires the FontTools package. It is recommended that you use the RoboFab installer with FontTools built in, available at the same page that this came from.

If you must pick up FontTools separately, download the latest snapshot here:
	http://fonttools.sourceforge.net/cvs-snapshots/gzip/fonttools-current-snapshot.tgz

-------------------------------------------
1.0 Installing RoboFab on MacPython on OSX, or most unix:
-------------------------------------------
run install.py in python

-------------------------------------------
1.1 Installing on OSX MacPython "OS9" 2.3, "for FontLab"
-------------------------------------------
FontLab 4.6 on OSX can work with MacPython "OS9" 2.3. Currently FontLab does not work with the Framework version of Python.

In Application/MacPython-OS9 2.3 find the PythonInterpreter. Then go to the directory where you downloaded robofab. Drag install.py to PythonInterpreter. If it says 'RoboFab is installed' you're done. Since FontLab uses this version of Python, this procedure has also installed RoboFab for use inside FontLab.

-------------------------------------------
1.2 Installing on other platforms
-------------------------------------------
Run install.py in a python interpreter.


-------------------------------------------
2.0 Testing
-------------------------------------------
Open a python interactive interpreter window.
type
	import robofab

If you don't get an traceback, you're good to go.

In Scripts/RoboFabIntro/ there are some test scripts, simple examples and some utilities. Read the source to learn more about what the examples do and where they want to run.


-------------------------------------------
3.0 Notes
-------------------------------------------
None so far.

-------------------------------------------
4.0 Contact the developers
-------------------------------------------
If you have questions about robofab. Note that it will be difficult for us to help everyone with installing. There is a non-public mailinglist for robofab developers. If you want to join, send a note to:

	robofab@letterror.com
	
RoboFab is only the beginning. We're planning some interesting premium tools on top of robofab. If you're interested in contracting us to extend Robofab in any direction, don't hesitate to contact us.
