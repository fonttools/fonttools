from warnings import warn
warn("The objectsMetrics module has been deprecated. It is now part of all font objects.",
	DeprecationWarning)

from robofab import RoboFabError
from robofab.objects.objectsBase import _interpolate, addPt, mulPt, subPt, Point, RBaseObject


class Offset:
	def __init__(self, glyphOne, glyphTwo, offset=0):
		"""The atom of the kerning world"""
		if isinstance(offset, tuple):
			self.offset = Point(offset)
		else:
			self.offset = Point((offset, 0))
		self.glyphOne = glyphOne
		self.glyphTwo = glyphTwo
	
	def __repr__(self):
		return "<Robofab Offset %s %s (%d, %d)>" %(self.glyphOne, self.glyphTwo, self.offset.x, self.offset.y)
		
	def __mul__(self, factor):
		return self.offset * factor
		
	def __add__(self, other):
		return self.offset + other.offset

	def __sub__(self, other):
		return self.offset - other.offset


		
class RKerning(RBaseObject):
	
	"""The RoboFab Kerning object. It behaves like a dict, but it has some kerning specific properties."""
	
	def __init__(self, kerningDict=None):
		if not kerningDict:
			kerningDict = {}
		self._kerning = kerningDict
			
	def __getitem__(self, key):
		if isinstance(key, tuple):
			pair = key
			return self.get(pair)
		elif isinstance(key, str):
			raise RoboFabError, 'kerning pair must be a tuple: (left, right)'
		else:
			keys = self.keys()
			if key > len(keys):
				raise IndexError
			keys.sort()
			pair = keys[key]
		if not self._kerning.has_key(pair):
			raise IndexError
		else:
			return pair
	
	def __setitem__(self, pair, value):
		if not isinstance(pair, tuple):
			raise RoboFabError, 'kerning pair must be a tuple: (left, right)'
		else:
			if len(pair) != 2:
				raise RoboFabError, 'kerning pair must be a tuple: (left, right)'
			else:
				if value == 0:
					if self._kerning.get(pair) is not None:
						del self._kerning[pair]
				else:
					self._kerning[pair] = value
	
	def __repr__(self):
		if self._kerning:
			l = " with %s pairs"%len(self._kerning)
		else:
			l = ""
		return '<RoboFab Kerning Object%s>'%l
		
	def __len__(self):
		return len(self._kerning.keys())
	
	def keys(self):
		"""return list of kerning pairs"""
		return self._kerning.keys()
		
	def values(self):
		"""return a list of kerning values"""
		return self._kerning.values()
	
	def items(self):
		"""return a list of kerning items"""
		return self._kerning.items()
		
	def hasPair(self, pair):
		"""return True if pair exists"""
		return self._kerning.has_key(pair)
	
	def get(self, pair):
		"""get a value. return 0 if the pair does not exist"""
		value = self._kerning.get(pair, 0)
		return value
		
	def remove(self, pair):
		"""remove a kerning pair"""
		self[pair] = 0
		
	def get_count(self):
		"""return the number of kerning pairs"""
		return len(self._kerning.keys())
	
	count = property(get_count, doc="return the number of  kerning pairs")
	
	def get_average(self):
		"""return average of all kerning pairs"""
		value = 0
		for i in self._kerning.values():
			value = value + i
		return value / float(len(self._kerning.keys()))
	
	average = property(get_average, doc="average of all kerning pairs")

	def get_extremes(self):
		"""return the lowest and highest kerning values"""
		if len(self._kerning.keys()) == 0:
			return 0
		values = self._kerning.values()
		values.append(0)
		values.sort() 
		return (values[0], values[-1])
	
	extremes = property(get_extremes, doc="the lowest and highest kerning values")

	def clear(self):
		"""clear all kerning"""
		self._kerning = {}
		
	def add(self, value):
		"""add value to all kerning pairs"""
		for pair in self._kerning.keys():
			self[pair] = self[pair] + value
		
	def scale(self, value):
		"""scale all kernng pairs by value"""
		for pair in self._kerning.keys():
			self._kerning[pair] = self._kerning[pair] * value
			
	def minimize(self, minimum=10):
		"""eliminate pairs with value less than minimum"""
		for pair in self._kerning.keys():
			if abs(self._kerning[pair]) < minimum:
				del self._kerning[pair]
	
	def eliminate(self, leftGlyphsToEliminate=None, rightGlyphsToEliminate=None):
		"""eliminate pairs containing a left glyph that is in the leftGlyphsToEliminate list
		or a right glyph that is in the rightGlyphsToELiminate list.
		sideGlyphsToEliminate can be a string: 'a' or list: ['a', 'b']"""
		lgte = leftGlyphsToEliminate
		rgte = rightGlyphsToEliminate
		if isinstance(lgte, str):
			lgte = [lgte]
		if isinstance(rgte, str):
			rgte = [rgte]
		for pair in self._kerning.keys():
			left, right = pair
			if left in lgte or right in rgte:
				del self._kerning[pair]
				
	def interpolate(self, sourceDictOne, sourceDictTwo, value, clearExisting=True):
		"""interpolate the kerning between sourceDictOne
		and sourceDictTwo. clearExisting will clear existing
		kerning first."""
		if clearExisting:
			self.clear()
		all = []
		for pair in sourceDictOne:
			all.append(pair)
		for pair in sourceDictTwo:
			if pair not in all:
				all.append(pair)
		for pair in all:
			s1 = sourceDictOne.get(pair)
			if not s1:
				s1 = 0
			s2 = sourceDictTwo.get(pair)
			if not s2:
				s2 = 0
			interpolated = _interpolate(s1, s2, value)
			self[pair] = interpolated
	
	def round(self, multiple=10):
		"""round the kerning pair values to increments of multiple"""
		for pair in self._kerning.keys():
			value = self._kerning[pair]
			self[pair] = int(round(value / float(multiple))) * multiple
	
	def occurrenceCount(self, glyphsToCount):
		"""return a dict with glyphs as keys and the number of 
		occurances of that glyph in the kerning pairs as the value
		glyphsToCount can be a string: 'a' or list: ['a', 'b']"""
		gtc = glyphsToCount
		if isinstance(gtc, str):
			gtc = [gtc]
		gtcDict = {}
		for i in gtc:
			gtcDict[i] = 0
		for pair in self._kerning.keys():
			left, right = pair
			if left == right:
				gtcDict[left] = gtcDict[left] + 1
				continue
			if left in gtc:
				gtcDict[left] = gtcDict[left] + 1
			if right in gtc:
				gtcDict[right] = gtcDict[right] + 1
		return gtcDict
	
	def getLeft(self, glyphName):
		"""Return a list of kerns with glyphName as left character."""
		hits = []
		for k, v in self._kerning.items():
			if k[0] == glyphName:
				hits.append((k, v))
		return hits
				
	def getRight(self, glyphName):
		"""Return a list of kerns with glyphName as left character."""
		hits = []
		for k, v in self._kerning.items():
			if k[1] == glyphName:
				hits.append((k, v))
		return hits
		
	def combine(self, kerningDicts, overwriteExisting=True):
		"""combine two or more kerning dictionaries.
		overwrite exsisting duplicate pairs if overwriteExisting=True"""
		if isinstance(kerningDicts, dict):
			kerningDicts = [kerningDicts]
		for kd in kerningDicts:
			for pair in kd.keys():
				exists = self.hasPair(pair)
				if exists and overwriteExisting:
					self[pair] = kd[pair]
				elif not exists:
					self[pair] = kd[pair]
					
	def swapNames(self, swapTable):
		"""change glyph names in all kerning pairs based on swapTable.
		swapTable = {'BeforeName':'AfterName', ...}"""
		for pair in self._kerning.keys():
			foundInstance = False
			left, right = pair
			if swapTable.has_key(left):
				left = swapTable[left]
				foundInstance = True
			if swapTable.has_key(right):
				right = swapTable[right]
				foundInstance = True
			if foundInstance:
				self._kerning[(left, right)] = self._kerning[pair]
				del self._kerning[pair]
				
	def explodeClasses(self, leftClassDict=None, rightClassDict=None):
		"""turn class kerns into real kerning pairs  classes should
		be defined in dicts: {'O':['C', 'G', 'Q'], 'H':['B', 'D', 'E', 'F', 'I']}"""
		if not leftClassDict:
			leftClassDict = {}
		if not rightClassDict:
			rightClassDict = {}
		for pair in self._kerning.keys():
			left, right = pair
			value = self._kerning[pair]
			if leftClassDict.get(left) and rightClassDict.get(right):
				allLeft = leftClassDict[left] + [left]
				allRight = rightClassDict[right] + [right]
				for leftSub in allLeft:
					for rightSub in allRight:
						self._kerning[(leftSub, rightSub)] = value
			elif leftClassDict.get(left) and not rightClassDict.get(right):
				allLeft = leftClassDict[left] + [left]
				for leftSub in allLeft:
					self._kerning[(leftSub, right)] = value
			elif rightClassDict.get(right) and not leftClassDict.get(left):
				allRight = rightClassDict[right] + [right]
				for rightSub in allRight:
					self._kerning[(left, rightSub)] = value
					
	def implodeClasses(self, leftClassDict=None, rightClassDict=None):
		"""condense the number of kerning pairs by applying classes.
		this will eliminate all pairs containg the classed glyphs leaving
		pairs that contain the key glyphs behind"""
		if not leftClassDict:
			leftClassDict = {}
		if not rightClassDict:
			rightClassDict = {}
		leftImplode = []
		rightImplode = []
		for value in leftClassDict.values():
			leftImplode = leftImplode + value
		for value in rightClassDict.values():
			rightImplode = rightImplode + value
		self.eliminate(leftGlyphsToEliminate=leftImplode, rightGlyphsToEliminate=rightImplode)
		
	def importAFM(self, path, clearExisting=True):
		"""Import kerning pairs from an AFM file. clearExisting=True will
		clear all exising kerning"""
		from fontTools.afmLib import AFM
		#some nasty hacks to fix line ending problems
		f = open(path, 'rb')
		text = f.read().replace('\r', '\n')
		f.close()
		f = open(path, 'wb')
		f.write(text)
		f.close()
		#/nasty hack
		kerning = AFM(path)._kerning
		if clearExisting:
			self._kerning = {}
		for pair in kerning.keys():
			self._kerning[pair] = kerning[pair]	
				
	def asDict(self, returnIntegers=True):
		"""call this when you are finished with the transformations
		and you want the kerning dict back"""
		if returnIntegers:
			for pair in self._kerning.keys():
				self._kerning[pair] = int(round(self._kerning[pair]))
		return self._kerning
		
			

if __name__ == '__main__':
	from robofab.interface.all.dialogs import GetFile
	#s1 = {('a', 'b'):10, ('x', 'y'):200}
	#s2 = {('a', 'b'):11}
	#d = {	('a', 'b'):1, ('x', 'y'):22, ('a', 'z'):33,
	#	('q', 'w'):44, ('t', 'y'):55, ('b', 'y'):6,
	#	('n', 'y'):77, ('r', 'y'):88, ('e', 'y'):99}
	#swap = {'a':'HELLO', 'y':'WORLD'}
	d = {('O', 'H'):-10, ('H', 'O'):20, ('X', 'H'):-40, ('O', 'Z'):30}
	leftClassDict = {'O':['D', 'Q'], 'H':['M', 'N']}
	rightClassDict = {'H':['E', 'F'], 'O':['C', 'G']}
	print
	k = RKerning(d)
	print k.count
	k.explodeClasses(leftClassDict, rightClassDict)
	print k.count
	k.implodeClasses(leftClassDict, rightClassDict)
	print k.count
	k.combine({('O', 'H'):100, ('N', 'A'):-20}, overwriteExisting=False)
	for p in k:
		print p, k[p]
