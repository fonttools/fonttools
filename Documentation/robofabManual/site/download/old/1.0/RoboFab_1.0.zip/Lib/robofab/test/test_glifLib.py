import os
import tempfile
import shutil
import unittest

from robofab.test.testSupport import getDemoFontGlyphSetPath
from robofab.glifLib import GlyphSet


GLYPHSETDIR = getDemoFontGlyphSetPath()


class GlyphSetRoundTripTestCase(unittest.TestCase):

	def setUp(self):
		self.dstDir = tempfile.mkdtemp()
	
	def tearDown(self):
		shutil.rmtree(self.dstDir)

	def testRoundTrip(self):
		srcDir = GLYPHSETDIR
		dstDir = self.dstDir
		src = GlyphSet(GLYPHSETDIR)
		dst = GlyphSet(dstDir)
		for glyphName in src.keys():
			g = src[glyphName]
			g.drawPoints(None)  # load attrs
			dst.writeGlyph(glyphName, g, g.drawPoints)
		# compare raw file data:
		for glyphName in src.keys():
			fileName = src.glyphNameToFileName(glyphName)
			org = file(os.path.join(srcDir, fileName), "rb").read()
			new = file(os.path.join(dstDir, fileName), "rb").read()
			self.assertEqual(org, new, "%r .glif file differs after round tripping" % glyphName)


if __name__ == "__main__":
	from robofab.test.testSupport import runTests
	import sys
	if len(sys.argv) > 1 and os.path.isdir(sys.argv[-1]):
		GLYPHSETDIR = sys.argv.pop()
	runTests()
