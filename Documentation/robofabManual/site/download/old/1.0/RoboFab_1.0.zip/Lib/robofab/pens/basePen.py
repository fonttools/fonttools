"""A really simple pen that just prints whatever it gets.
To illustrate the functioning of pens and how they interact
with glyph objects.
"""



class BasePen:
	"""Base class for pens, this one just  prints when it's called"""
	def __init__(self, glyph):
		print 'BasePen init'
	
	def moveTo(self, pt, smooth=False):
		print 'BasePen moveTo', pt, smooth
		
	def lineTo(self, pt, smooth=False):
		print 'BasePen lineTo', pt, smooth
		
	def curveTo(self, pt1, pt2, pt3, smooth=False):
		print 'BasePen curveTo', pt1, pt2, pt3, smooth
		
	def qCurveTo(self, *pts, **kwargs):
		print 'BasePen qCurveTo', pts, kwargs
	
	def closePath(self):
		print 'BasePen closePath'
	
	def addComponent(self, baseName, offset=(0, 0), scale=(1, 1)):
		print 'BasePen addComponent', baseName
		
	def addAnchor(self, name, (x, y)):
		print 'BasePen addAnchor', name
	
	def setWidth(self, width):
		print 'BasePen setWidth', width

	def setNote(self, note):
		print 'BasePen setNote', note
		
	def doneDrawing(self):
		print 'BasePen doneDrawing'
		
