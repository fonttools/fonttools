#FLM: Import .ufo File into FontLab

from robofab.world import NewFont
from robofab.interface.all.dialogs import GetFolder

font = NewFont()
path = GetFolder()
font.readUFO(path, doProgress=True)
font.update()
print 'DONE!'
