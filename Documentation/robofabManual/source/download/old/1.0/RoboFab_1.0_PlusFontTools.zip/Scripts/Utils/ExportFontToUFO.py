#FLM: Export Font to .ufo Format

from robofab.world import CurrentFont

f = CurrentFont()
f.writeUFO(doProgress=True)
print 'DONE!'