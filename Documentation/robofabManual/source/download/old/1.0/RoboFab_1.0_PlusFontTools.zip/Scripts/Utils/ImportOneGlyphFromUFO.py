#FLM: GLIF Grabber

"""Import one glyph from a .ufo"""

from robofab.world import CurrentFont
from robofab.objects.objectsRF import OpenFont
from robofab.interface.all.dialogs import SelectGlyph

flFont = CurrentFont()
# pick a .ufo
rfFont = OpenFont()
if rfFont is not None:
	# pick a glyph in the .ufo
	rfGlyph = SelectGlyph(rfFont)
	if rfGlyph is not None:
		# make a new glyph in the FL font
		flGlyph = flFont.newGlyph(rfGlyph.name, clear=True)
		# draw the glyph into the FL font
		pen = flGlyph.getPointPen()
		rfGlyph.drawPoints(pen)
		# set the width, unicodes and lib
		flGlyph.width = rfGlyph.width
		flGlyph.unicodes = rfGlyph.unicodes
		flGlyph.lib = rfGlyph.lib
		flGlyph.update()
		flFont.update()
