"""

Directory for interface related modules.
Stuff for any and all platforms, anything
that goes here should work on mac and win, or in FontLab proper.

"""




