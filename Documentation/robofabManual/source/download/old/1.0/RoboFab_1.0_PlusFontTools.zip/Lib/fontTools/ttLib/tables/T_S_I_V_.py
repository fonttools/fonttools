import asciiTable

class table_T_S_I_V_(asciiTable.asciiTable):
	pass

