"""
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 

W A R N I N G

This is work in progress, a fast moving target.

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
"""



"""Glyph Properties (not to be confused with python property) are pieces of data and code that
belong to a specific glyph, but they're not basic glyph ingredients as contours or components."""

from robofab.objects.objectsBase import RBaseObject
from robofab import RoboFabError
from types import StringType, TupleType
__version__ = "0.1"


def makeAttrName(className):
	return className[0].lower()+className[1:]




class BaseGlyphProperties(RBaseObject):
	"""Base for a container of all glyph properties. Reads and writes to a plistable dict.
	In order to make it easy to store different classes of objects in GlyphProperties,
	the class of object is determined by the data read from the plist."""
	def __init__(self, data):
		RBaseObject.__init__(self)
		self._names = {}
		if data is not None:
			self.fromDict(data)
	
	def __repr__(self):
		if self.getParent() is not None:
			parentName = self.getParent().name
		else:
			parentName = "no Glyph"
		return '<RoboFab GlyphProperties for "%s" at %s>'%(parentName, id(self))
		
	def isEmpty(self):
		if len(self._names) > 0:
			return False
		return True
	
	def fromDict(self, data):
		"""Read the dict and try to match the keys with classes.
		Make a new instance for each entry. Keep a list of which 
		items come from the data, to make exporting easier."""
		for className, instanceNames in data.items():
			if className == "metaData":
				#if data['metaData']['version'] is not __version__:
				#	print "Properties Warning: the data was written with a different version of RoboFab.properties! Proceed with caution."
				continue
			for name in instanceNames:
				self._newPropertyAttribute(className, name, data[className][name])
	
	def _newPropertyAttribute(self, className, instanceName, data):
		if globals().has_key(className):
			attrName = makeAttrName(className)
			prop = globals()[className](instanceName, data)
			prop.setParent(self)
			if hasattr(self, attrName):
				getattr(self, attrName)[instanceName] = prop
			else:
				setattr(self, attrName,  {instanceName:prop})
				self._names[attrName]  = className
		else:
			print "Encountered unknown property class: %s"%(className)
		
	def asDict(self):
		"""Export the properties back to plist-ready dict. 
		Ask each of the property instances to export themselves."""
		export = {}
		if len(self._names) == 0:
			# no properties stored, dont' save anything
			return None
		export['metaData'] = {"version":__version__}
		for attrName in self._names:
			for instanceName, instance in getattr(self, attrName).items():
				aClass = self._names[attrName]
				if not export.has_key(aClass):
					export[aClass] = {}
				export[aClass][instanceName] = instance.write()
		return export
	

class GlyphProperties(BaseGlyphProperties):
	"""Container of all glyph properties.  These are things like interpolation axes, layer information, etc."""
	
	def __init__(self, data=None):
		BaseGlyphProperties.__init__(self, data)
	
	# methods that deal with glyphs
	def getGlyph(self, glyphName,  nested=0):
		"""Retrieve a glyph, either from the parent glyphset or from one of the instanceFactories.
		Keeps a count of nested calls, a requested glyph might possibly come from an instanceFactory which
		requires the same glyph. Recursive glyph dependencies are obviously illegal,
		but we need to be able to warn the user when the data is wrong. """
		if self.getParent() is None:
			print "GlyphProperties, no parent"
			return None
		pg = self.getParent()
		try:
			# first see if the parent glyphset has it
			ref = pg.getGlyph(glyphName)
			return ref
		except IndexError:
			pass
		if nested < 20:
			# we haven't found the glyph at the parent
			# but maybe it is a synthetic glyph itself, 
			# see if one of the Instance Factories has one in stock
			if hasattr(self, 'instanceFactory'):
				if self.instanceFactory.has_key(glyphName):
					return self.instanceFactory[glyphName].makeInstance(nested=nested)
				else:
					raise RoboFabError, "Properties: trying to get a glyph that doesn't exist: ", glyphName
		else:
			raise RoboFabError, "Glyph Properties nested too deep (>%d), maybe a recursion error?"%nested

	# methods that deal with axes
	def getAxesGlyphNames(self):
		if not hasattr(self, 'axis'):
			return []
		m = {}
		for s, f in self.axis.items():
			for sm in f.getGlyphNames():
				m[sm] = 1
		k = m.keys()
		k.sort()
		return k
	
	def getAxis(self, axisName):
		if not hasattr(self, 'axis'):
			return None
		return self.axis.get(axisName, None)
		
	def getAxisGlyphs(self, axisName, nested=0):
		if not hasattr(self, 'axis'):
			return []
		glyphs = {}
		names = self.axis[axisName].getGlyphNames()
		nested = nested+1
		for n in names:
			glyphs[n] = self.getGlyph(n, nested=nested)
		return glyphs
	
	def getAxesNames(self):
		if not hasattr(self, 'axis'):
			return []
		return self.axis.keys()
		
	# methods that deal with layers
	def getLayersNames(self):
		return self.layer.keys()
		
	def getLayer(self, layerName):
		return self.layer[layerName]
		
	def getLayersGlyphNames(self):
		m = {}
		for s, f in self.layer.items():
			for sm in f.getGlyphNames():
				m[sm] = 1
		k = m.keys()
		k.sort()
		return k
			
	# methods that deal with factories
	def getNamesSyntheticGlyphs(self):
		if not hasattr(self, "instanceFactory"):
			return []
		return self.instanceFactory.keys()

	def getInstanceFactories(self):
		if not hasattr(self, "instanceFactory"):
			return []
		return self.instanceFactory.items()
		
	def makeInstances(self):
		"""Make all instances defined by all instanceFactories in this GlyphProperties object."""
		if not hasattr(self, "instanceFactory"):
			return
		for name in self.instanceFactory.keys():
			glyph = self.instanceFactory[name].makeInstance()
			if self.getParent() is not None and glyph is not None:
				self.getParent().insertGlyph(glyph)
	
	def getInstanceFactoryGlyphNames(self):
		if not hasattr(self, "instanceFactory"):
			return []
		m = {}
		for s, f in self.instanceFactory.items():
			for sm in f.getGlyphNames():
				m[sm] = 1
		k = m.keys()
		k.sort()
		return k


class BasePropertyItem(RBaseObject):
	"""A base class for one specific glyph property. Methods for reading and writing a plistable dict."""
	def __init__(self, name, data):
		self.name = name
		self._data = data
		if data is not None:
			for k in data.keys():
				setattr(self, k, data[k])
	
	def write(self):
		"""Write this property in a plist ready format"""
		return {}

	def __repr__(self):
		return '<RoboFab Glyph Property "%s">' %(self.name)

	def getGlyphNames(self):
		"""Make a list of needed glyphs for this property."""
		return []


class BaseInstanceFactory(BasePropertyItem):
	"""Base for information about making an instance by interpolation, assembly, trickery."""
	
	def write(self):
		export = {}
		export['actions'] = self.actions
		return export

	def __repr__(self):
		return '<RoboFab Instance Factory Property "%s">' %(self.name)


class BaseAxis(BasePropertyItem):
	"""Base for a complete interpolation axis which contains one or more segments.
	Each segment is an interpolation between two masters. An axis can therefor
	contain inbetween masters. For instance:
		light -> regular ->black,
	or even discontinuous designs. For instance:
		light.barreddollar-> regular.barreddollar -> bold.barreddollar/bold.nobardollar -> black.nobardollar
	"""
	def write(self):
		export = {}
		export['scale'] = self.scale
		export['segment'] = self.segment
		return export
	
	def __repr__(self):
		return '<RoboFab Axis Property "%s">' %(self.name)
	

class BaseLayer(BasePropertyItem):
	"""Base for a description of a layer. Can be for coloring, layering, whatever."""

	def needGlyphs(self):
		"""Make a list of needed glyphs for this property."""
		return None

	def __repr__(self):
		return '<RoboFab Layer Property "%s">' %(self.name)

	def write(self):
		export = {}
		export['colorModel'] = self.colorModel
		export['glyph'] = self.glyph
		export['note'] = self.note
		export['order'] = self.order
		return export
	
	
	
	
	
class Axis(BaseAxis):
	
	def getGlyphNames(self):
		"""Make a list of glyph names needed by this axis."""
		glyphs = {}
		names = []
		for minBit, maxBit, minName, maxName in self.segment:
			names.append(minName)
			names.append(maxName)
		for name in names:
			if type(name) == StringType:
				# it's a glyphname
				glyphs[name] = 1
			else:
				# it's axis name / value tuple
				# use a result of another axis as an extreme in this axis
				# without adding it to the glyphset.
				axis, value = name
				if axis == self.name:
					raise RoboFabError, "Recursive axis definition %s."%(self.name)
				if self.getParent() is None:
					raise RoboFabError, "Axis without parent."
				ax = self.getParent().getAxis(axis)
				if ax is None:
					raise RoboFabError, "Unknown axis (%s) requested by%s."%(axis, self.name)
				superAxisNames =  ax.getGlyphNames()
				for gn in ax.getGlyphNames():
					glyphs[gn]= 1
		k = glyphs.keys()
		k.sort()
		return k

	def findSegment(self, factor):
		scaled = float(factor)/self.scale
		if scaled > 1:
			# extrapolate
			print 'Not implemented! findsegment extrapolate >> 1', scaled
		elif scaled < 0:
			# extrapolate
			print 'Not implemented! findsegment extrapolate << 0', scaled
		localFactor = 0
		for minValue, maxValue, minGlyph, maxGlyph in self.segment:
			if minValue < factor <= maxValue:
				localFactor = scaled-minValue*(float(maxValue)/self.scale)
				return localFactor, minGlyph, maxGlyph
	
	def interpolate(self, glyphs, factor):
		segment = self.findSegment(factor)
		localFactor, inGlyph, outGlyph = self.findSegment(factor)
		if type(inGlyph) is StringType:
			a = glyphs[inGlyph]
		else:
			axis, value = inGlyph
			a = self.getParent().getAxis(axis).interpolate(glyphs, value)
		if type(outGlyph) is StringType:
			b = glyphs[outGlyph]
		else:
			axis, value = outGlyph
			b = self.getParent().getAxis(axis).interpolate(glyphs, value)
		goodToGo, report = a.isCompatible(b, report=True)
		if not goodToGo:
			print report
			return None
		if a is not None and b is not None:
			g = a + (b-a)*localFactor
			return g
		else:
			print "Axis.interpolate: no masters!"
			return None


class Layer(BaseLayer):
	pass	

class InstanceFactory(BaseInstanceFactory):
	
	def __init__(self, name, data=None):
		BaseInstanceFactory.__init__(self, name, data)
		self._workingGlyph = None

	def getActions(self):
		"""Return a list of the specified actions."""
		return self.actions
	
	def supportedActions(self):
		"""Return a list of all actions that are supported in this factory."""
		methods = self.__class__.__dict__.keys()
		sup = []
		for k in methods:
			if k[:8] == "_action_":
				sup.append(k)
		sup.sort()
		return sup
	
	def makeInstance(self, nested=0):
		"""Execute all the actions and generate a new glyph."""
		from robofab.objects.objectsRF import RGlyph
		self._workingGlyph = RGlyph()
		self._workingGlyph._synthetic = True
		self._actionNameSpace = {}	# the namesp
		for actionName, attrs in self.actions:
			if hasattr(self, "_action_"+actionName):
				result = getattr(self, "_action_"+actionName)(attrs, nested)
			else:
				result = self._unsuportedAction(actionName)
			if result is None:
				#print "something went wrong in making this glyph", self.name
				break
			else:
				self_workingGlyph = result
		if self._workingGlyph is not None:
			self._workingGlyph.note = "Generated by factory %s"%(self.name)
			self._workingGlyph.name = self.name
			return self._workingGlyph
		return None
	
	# action methods
	def _unsuportedAction(self, actionName):
		print "Action %s is not supported" %actionName
	
	def _action_interpolate(self, attrs, nested=0):
		axisName = attrs['axis']
		if not axisName in self.getParent().getAxesNames():
			raise RoboFabError, "Error in Properties: Axis %s is not defined"%(axisName)
		axis = self.getParent().getAxis(axisName)
		value = int(attrs['value'])
		masters = self.getParent().getAxisGlyphs(axisName, nested)
		self._workingGlyph = axis.interpolate(masters, value)
			
	def _action_decompose(self, attrs, nested=0):
		pass
		#print 'action_decompose', attrs
			
	def _action_scale(self, attrs, nested=0):
		pass
		#print 'action_scale', attrs
			
	def _action_offset(self, attrs, nested=0):
		pass
		#print 'action_offset', attrs
			
	def _action_removeoverlap(self, attrs, nested=0):
		pass
		#print 'action_removeoverlap __you wish', attrs
		
	# EXPERIMENTAL
	
	def _action_start(self, attrs):
		#print 'action_start -- get initial outline', attrs
		name = attrs['glyph']		
		
	def _action_add(self, attrs):
		#print 'action_add -- add a delta', attrs
		name = attrs['glyph']		

	
	

if __name__ == "__main__":
	
	# no longer needed for actual data, but it is nice to have some reference
	# of what goes in the org.robofab.properties plist.
	
	testProperties = {
	# a dict of properties as they should come out of the glyph.lib
	# version info of the reader/writer that made the data
	"metaData": {"version": 0.1},
	
	"InstanceFactory": {
		# factories: recepies for making glyphs
		"a#width_500_light": {
			"actions":	[("interpolate", {"value": 500, "axis": "width_light"},),
					("decompose", {},),
					("removeoverlap", {},),
					]
				},
		"a#width_500_bold": {
			"actions":	[("interpolate", {"value": 500, "axis": "width_bold"},),
					("decompose", {},),
					("removeoverlap", {},),
					]
				},
		"a#width_500_weight_500": {
			"actions":	[("interpolate", {"value": 500, "axis": "weight_width_500"},),
					("decompose", {},),
					("removeoverlap", {},),
					]
				},
	},
	
	"Layer": {
			# layering info
			"red": {'glyph':"a#layerOne",
					'order':"00010",
					'colorModel':"CMYK",
					'note':"left!",
					},
			"blue": {'glyph':"a#layerOne",
					'order':"10010",
					'colorModel':"CMYK",
					'note':"left!",
					},
	},
	
	"Axis": {
		# axis for interpolation
		"width_light": {
				'scale':1000,
				'segment': [	(0, 1000, "a#condensed_light", "a#wide_light"),
					],
			},
		"width_bold": {
				'scale':1000,
				'segment': [	(0, 1000, "a#condensed_bold", "a#wide_bold"),
					],
			},
		"weight_width_500": {
				'scale':1000,
				'segment': [	(0, 1000, ("width_light", 499), ("width_bold", 203)),
					],
			},
		}
	}
		
	
	from robofab.world import OpenFont, world
	f = OpenFont(None, 'Select a .ufo font to look at')
	if f:
		# force these demo properties into the regular .glif world, JUST ONCE.
		gp = GlyphProperties(testProperties)
		#f['a'].properties = gp
				
		print "hey!", f['a#width_500_light'] # this one is defined as a factory
		#print f['a'] # this one is not defined as a factory
#		#print f['a#xxxx'] # this one is not defined as a factory
#		f.save()
		
		for c in f:
			print c.name, c._synthetic, c
