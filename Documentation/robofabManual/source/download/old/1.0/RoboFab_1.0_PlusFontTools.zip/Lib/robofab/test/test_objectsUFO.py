"""This test suite for ufo glyph methods"""


import unittest
import os

from robofab.objects.objectsRF import RFont
from robofab.test.testSupport import getDemoFontPath
from robofab.pens.digestPen import DigestPointPen
from robofab.pens.adapterPens import SegmentToPointPen, FabToFontToolsPenAdapter


class ContourMethodsTestCase(unittest.TestCase):
	
	def setUp(self):
		self.font = RFont(getDemoFontPath())
	
	def testReverseContour(self):
		for glyph in self.font:
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest1 = pen.getDigest()
			for contour in glyph:
				contour.reverseContour()
				contour.reverseContour()
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest2 = pen.getDigest()
			self.assertEqual(digest1, digest2, "%r not the same after reversing twice" % glyph.name)
	
	def testStartSegment(self):
		for glyph in self.font:
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest1 = pen.getDigest()
			for contour in glyph:
				contour.setStartSegment(2)
				contour.setStartSegment(-2)
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest2 = pen.getDigest()
			self.assertEqual(digest1, digest2, "%r not the same after seting start segment twice" % glyph.name)
	
	def testAppendSegment(self):
		for glyph in self.font:
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest1 = pen.getDigest()
			for contour in glyph:
				contour.insertSegment(2, "curve", [(100, 100), (200, 200), (300, 300)])
				contour.removeSegment(2)
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest2 = pen.getDigest()
			self.assertEqual(digest1, digest2, "%r not the same after inserting and removing segment" % glyph.name)
	

class GlyphsMethodsTestCase(ContourMethodsTestCase):

	def testCopyGlyph(self):
		for glyph in self.font:
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest1 = pen.getDigest()
			copy = glyph.copy()
			pen = DigestPointPen()
			copy.drawPoints(pen)
			digest2 = pen.getDigest()
			self.assertEqual(digest1, digest2, "%r not the same after copying" % glyph.name)
			self.assertEqual(glyph.lib, copy.lib, "%r's lib not the same after copying" % glyph.name)
			self.assertEqual(glyph.width, copy.width, "%r's width not the same after copying" % glyph.name)
			self.assertEqual(glyph.unicodes, copy.unicodes, "%r's unicodes not the same after copying" % glyph.name)

	def testMoveGlyph(self):
		for glyph in self.font:
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest1 = pen.getDigest()
			glyph.move((100, 200))
			glyph.move((-100, -200))
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest2 = pen.getDigest()
			self.assertEqual(digest1, digest2, "%r not the same after moving twice" % glyph.name)
	
	def testScaleGlyph(self):
		for glyph in self.font:
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest1 = pen.getDigest()
			glyph.scale((2, 2))
			glyph.scale((.5, .5))
			pen = DigestPointPen()
			glyph.drawPoints(pen)
			digest2 = pen.getDigest()
			self.assertEqual(digest1, digest2, "%r not the same after scaling twice" % glyph.name)

	def testSegmentPenInterface(self):
		for glyph in self.font:
			digestPen = DigestPointPen(ignoreSmoothAndName=True)
			pen = SegmentToPointPen(digestPen)
			glyph.draw(pen)
			digest1 = digestPen.getDigest()
			digestPen = DigestPointPen(ignoreSmoothAndName=True)
			glyph.drawPoints(digestPen)
			digest2 = digestPen.getDigest()
			self.assertEqual(digest1, digest2, "%r not the same for gl.draw() and gl.drawPoints()" % glyph.name)

	def testFabPenCompatibility(self):
		for glyph in self.font:
			digestPen = DigestPointPen(ignoreSmoothAndName=True)
			pen = FabToFontToolsPenAdapter(SegmentToPointPen(digestPen))
			glyph.draw(pen)
			digest1 = digestPen.getDigest()
			digestPen = DigestPointPen(ignoreSmoothAndName=True)
			glyph.drawPoints(digestPen)
			digest2 = digestPen.getDigest()
			self.assertEqual(digest1, digest2, "%r not the same for gl.draw() and gl.drawPoints()" % glyph.name)


class SaveTestCase(ContourMethodsTestCase):

	def testSaveAs(self):
		import tempfile, shutil
		path = tempfile.mktemp(".ufo", "robofab")
		try:
			keys = self.font.keys()
			self.font.save(path)
			self.assertEqual(keys, self.font.keys())
			self.assertEqual(self.font.path, path)
			font2 = RFont(path)
			self.assertEqual(keys, font2.keys())
		finally:
			if os.path.exists(path):
				shutil.rmtree(path)

	def testSaveAs2(self):
		import tempfile, shutil
		path = tempfile.mktemp(".ufo", "robofab")
		# copy a glyph
		self.font["X"] = self.font["a"].copy()
##		self.font["X"].name = "X"  # XXX should not be needed!
		# remove a glyph
		self.font.removeGlyph("a")
		keys = self.font.keys()
		try:
			self.font.save(path)
			self.assertEqual(self.font.path, path)
			self.assertEqual(keys, self.font.keys())
			font2 = RFont(path)
			self.assertEqual(keys, font2.keys())
		finally:
			if os.path.exists(path):
				shutil.rmtree(path)


if __name__ == "__main__":
	from robofab.test.testSupport import runTests
	runTests()
