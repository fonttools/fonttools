import asciiTable

class table_T_S_I_D_(asciiTable.asciiTable):
	pass

