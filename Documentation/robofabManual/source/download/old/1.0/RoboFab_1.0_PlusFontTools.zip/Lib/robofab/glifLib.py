"""glifLib.py -- Generic module for reading and writing the .glif format.

More info about the .glif format (GLyphInterchangeFormat) can be found here:

  http://just.letterror.com/ltrwiki/GlyphInterchangeFormat

The main class in this module is GlyphSet. It manages a set of .glif files
in a folder. It offers two ways to read glyph data, and one way to write
glyph data. See the class doc string for details.
"""

__all__ = ["GlyphSet", "GlifLibError",
		"readGlyphFromString", "writeGlyphToString"]

import os
from robofab.xmlTreeBuilder import buildTree, stripCharacterData
from robofab.pens.pointPen import AbstractPointPen
from cStringIO import StringIO


class GlifLibError(Exception): pass


if os.name == "mac":
	WRITE_MODE = "wb"  # use unix line endings, even with Classic MacPython
	READ_MODE = "rb"
else:
	WRITE_MODE = "w"
	READ_MODE = "r"


class Glyph:

	"""Minimal glyph object. It has no glyph attributes until either
	the draw() or the drawPoint() method has been called.
	"""

	def __init__(self, glyphName, glyphSet):
		self.glyphName = glyphName
		self.glyphSet = glyphSet

	def draw(self, pen):
		"""Draw this glyph onto a *FontTools* Pen."""
		from robofab.pens.adapterPens import PointToSegmentPen
		pointPen = PointToSegmentPen(pen)
		self.drawPoints(pointPen)

	def drawPoints(self, pointPen):
		"""Draw this glyph onto a PointPen."""
		self.glyphSet.readGlyph(self.glyphName, self, pointPen)


def _stripGlyphXMLTree(nodes):
	for element, attrs, children in nodes:
		# "lib" is formatted as a plist, so we need unstripped
		# character data so we can support strings with leading or
		# trailing whitespace. Do strip everything else.
		recursive = (element != "lib")
		stripCharacterData(children, recursive=recursive)


def _relaxedSetattr(object, attr, value):
	try:
		setattr(object, attr, value)
	except AttributeError:
		pass


def number(s):
	"""Given a numeric string, return an integer or a float, whichever
	the string indicates. number("1") will return the integer 1,
	number("1.0") will return the float 1.0.
	"""
	try:
		n = int(s)
	except ValueError:
		n = float(s)
	return n


class GlyphSet:

	"""GlyphSet manages a set of .glif files inside one directory.

	GlyphSet's constructor takes a path to an existing directory as it's
	first argument. Reading glyph data can either be done through the
	readGlyph() method, or by using GlyphSet's dictionary interface, where
	the keys are glyph names and the values are (very) simple glyph objects.

	To write a glyph to the glyph set, you use the writeGlyph() method.
	The simple glyph objects returned through the dict interface do not
	support writing, they are just means as a convenient way to get at
	the glyph data.
	"""

	glyphClass = Glyph

	def __init__(self, dirName, glifExtension="glif"):
		"""'dirName' should be a path to an existing directory. Glyph
		files written to that directory will by default have a ".glif"
		extension. The 'glifExtension' argument allows you to specify
		the extension to be used.
		"""
		self.dirName = dirName
		self.glifExtension = glifExtension
		self.contents = self._findContents()

	def rebuildContents(self):
		"""Rebuild the contents dict by checking what glyphs are available
		on disk.
		"""
		self._findContents(forceRebuild=True)

	def writeContents(self):
		"""Write the contents.plist file out to disk. Call this method when
		you're done writing glyphs.
		"""
		from plistlib import writePlist
		contentsPath = os.path.join(self.dirName, "contents.plist")
		writePlist(self.contents, contentsPath)

	# reading/writing API

	def readGlyph(self, glyphName, glyphObject=None, pointPen=None):
		"""Read a .glif file for 'glyphName' from the glyph set. The
		'glyphObject' argument can be any kind of object (even None);
		the readGlyph() method will attempt to set the following
		attributes on it:
			"width"     the advance with of the glyph
			"unicodes"  a list of unicode values for this glyph
			"note"      a string
			"lib"       a dictionary containing custom data

		All attributes are optional, in two ways:
			1) An attribute *won't* be set if the .glif file doesn't
			   contain data for it. 'glyphObject' will have to deal
			   with default values itself.
			2) If setting the attribute fails with an AttributeError
			   (for example if the 'glyphObject' attribute is read-
			   only), readGlyph() will not propagate that exception,
			   but ignore that attribute.

		To retrieve outline information, you need to pass an object
		conforming to the PointPen protocol as the 'pointPen' argument.
		This argument may be None if you don't need the outline data.

		readGlyph() will raise KeyError if the glyph is not present in
		the glyph set.
		"""
		tree = self._getXMLTree(glyphName)
		_readGlyphFromTree(tree, glyphObject, pointPen)

	def writeGlyph(self, glyphName, glyphObject=None, drawPointsFunc=None):
		"""Write a .glif file for 'glyphName' to the glyph set. The
		'glyphObject' argument can be any kind of object (even None);
		the writeGlyph() method will attempt to get the following
		attributes from it:
			"width"     the advance with of the glyph
			"unicodes"  a list of unicode values for this glyph
			"note"      a string
			"lib"       a dictionary containing custom data

		All attributes are optional: if 'glyphObject' doesn't
		have the attribute, it will simply be skipped.

		To write outline data to the .glif file, writeGlyph() needs
		a function (any callable object actually) that will take one
		argument: an object that conforms to the PointPen protocol.
		The function will be called by writeGlyph(); it has to call the
		proper PointPen methods to transfer the outline to the .glif file.
		"""
		from xmlWriter import XMLWriter
		data = writeGlyphToString(glyphName, glyphObject, drawPointsFunc)

		fileName = self.contents.get(glyphName)
		if fileName is None:
			fileName = self.glyphNameToFileName(glyphName)
			self.contents[glyphName] = fileName
		path = os.path.join(self.dirName, fileName)
		if os.path.exists(path):
			f = open(path, READ_MODE)
			oldData = f.read()
			f.close()
			if data == oldData:
				return
		f = open(path, WRITE_MODE)
		f.write(data)
		f.close()

	def deleteGlyph(self, glyphName):
		"""Permanently delete the glyph from the glyph set on disk. Will
		raise KeyError if the glyph is not present in the glyph set.
		"""
		fileName = self.contents[glyphName]
		os.remove(os.path.join(self.dirName, fileName))
		del self.contents[glyphName]

	# dict-like support

	def keys(self):
		return self.contents.keys()

	def has_key(self, glyphName):
		return glyphName in self.contents

	__contains__ = has_key

	def __len__(self):
		return len(self.contents)

	def __getitem__(self, glyphName):
		if glyphName not in self.contents:
			raise KeyError, glyphName
		return self.glyphClass(glyphName, self)

	# methods overridable for custom file naming

	def glyphNameToFileName(self, glyphName):
		"""Convert a glyph name to a file name, for example:
			'a'     -> 'a.glif'
			'A'     -> 'A_.glif'
			'A.alt' -> 'A_.alt.glif'
		"""
		parts = glyphName.split(".")
		if parts[0] != parts[0].lower():
			parts[0] += "_"
		if self.glifExtension:
			parts.append(self.glifExtension)
		return ".".join(parts)

	def fileNameToGlyphName(self, fileName):
		"""Convert a file name to a glyph name, for example:
			'a.glif'      -> 'a'
			'A_.glif'     -> 'A'
			'A_.alt.glif' -> 'A.alt'
		"""
		parts = fileName.split(".")
		if self.glifExtension:
			assert parts[-1] == self.glifExtension
			del parts[-1]
		baseName = parts[0]
		while baseName and baseName[-1] == "_":
			baseName = baseName[:-1]
		parts[0] = baseName
		return ".".join(parts)

	# internal methods

	def _findContents(self, forceRebuild=False):
		contentsPath = os.path.join(self.dirName, "contents.plist")
		if forceRebuild or not os.path.exists(contentsPath):
			ext = self.glifExtension
			fileNames = os.listdir(self.dirName)
			fileNames = [n for n in fileNames if n.endswith(ext)]
			contents = {}
			for n in fileNames:
				contents[self.fileNameToGlyphName(n)] = n
		else:
			from plistlib import readPlist
			contents = readPlist(contentsPath)
		return contents

	def _getXMLTree(self, glyphName):
		fileName = self.contents[glyphName]
		path = os.path.join(self.dirName, fileName)
		if not os.path.exists(path):
			raise KeyError, glyphName
		return _glifTreeFromFile(path)


def _glifTreeFromFile(aFile):
	tree = buildTree(aFile, stripData=False)
	stripCharacterData(tree[2], recursive=False)
	assert tree[0] == "glyph"
#	assert tree[1]["name"] == glyphName
	_stripGlyphXMLTree(tree[2])
	return tree


def _readGlyphFromTree(tree, glyphObject=None, pointPen=None):
	unicodes = []
	assert tree[0] == "glyph"
	formatVersion = int(tree[1].get("format", "0"))
	if formatVersion not in (0, 1):
		raise GlifLibError, "unsupported glif format version: %s" % formatVersion
	for element, attrs, children in tree[2]:
		if element == "outline":
			if pointPen is not None:
				if formatVersion == 0:
					buildOutline_Format0(pointPen, children)
				else:
					buildOutline_Format1(pointPen, children)
		elif glyphObject is None:
			continue
		elif element == "advance":
			width = number(attrs["width"])
			_relaxedSetattr(glyphObject, "width", width)
		elif element == "unicode":
			unicodes.append(int(attrs["hex"], 16))
		elif element == "note":
			rawNote = "\n".join(children)
			lines = rawNote.split("\n")
			lines = [line.strip() for line in lines]
			note = "\n".join(lines)
			_relaxedSetattr(glyphObject, "note", note)
		elif element == "lib":
			from plistFromTree import readPlistFromTree
			assert len(children) == 1
			lib = readPlistFromTree(children[0])
			_relaxedSetattr(glyphObject, "lib", lib)
	if unicodes:
		_relaxedSetattr(glyphObject, "unicodes", unicodes)


def readGlyphFromString(aString, glyphObject=None, pointPen=None):
	"""Read .glif data from a string into a glyph object.

	The 'glyphObject' argument can be any kind of object (even None);
	the readGlyphFromString() method will attempt to set the following
	attributes on it:
		"width"     the advance with of the glyph
		"unicodes"  a list of unicode values for this glyph
		"note"      a string
		"lib"       a dictionary containing custom data

	All attributes are optional, in two ways:
		1) An attribute *won't* be set if the .glif file doesn't
		   contain data for it. 'glyphObject' will have to deal
		   with default values itself.
		2) If setting the attribute fails with an AttributeError
		   (for example if the 'glyphObject' attribute is read-
		   only), readGlyphFromString() will not propagate that
		   exception, but ignore that attribute.

	To retrieve outline information, you need to pass an object
	conforming to the PointPen protocol as the 'pointPen' argument.
	This argument may be None if you don't need the outline data.
	"""
	tree = _glifTreeFromFile(StringIO(aString))
	_readGlyphFromTree(tree, glyphObject, pointPen)


def writeGlyphToString(glyphName, glyphObject=None, drawPointsFunc=None):
	"""Return .glif data for a glyph as a UTF-8 encoded string.
	The 'glyphObject' argument can be any kind of object (even None);
	the writeGlyphToString() method will attempt to get the following
	attributes from it:
		"width"     the advance with of the glyph
		"unicodes"  a list of unicode values for this glyph
		"note"      a string
		"lib"       a dictionary containing custom data

	All attributes are optional: if 'glyphObject' doesn't
	have the attribute, it will simply be skipped.

	To write outline data to the .glif file, writeGlyphToString() needs
	a function (any callable object actually) that will take one
	argument: an object that conforms to the PointPen protocol.
	The function will be called by writeGlyphToString(); it has to call the
	proper PointPen methods to transfer the outline to the .glif file.
	"""
	from xmlWriter import XMLWriter
	aFile = StringIO()
	writer = XMLWriter(aFile, encoding="UTF-8")
	writer.begintag("glyph", [("name", glyphName), ("format", "1")])
	writer.newline()

	width = getattr(glyphObject, "width", None)
	if width is not None:
		if not isinstance(width, (int, float)):
			raise GlifLibError, "width attribute must be int or float"
		writer.simpletag("advance", width=str(width))
		writer.newline()

	unicodes = getattr(glyphObject, "unicodes", None)
	if unicodes:
		if isinstance(unicodes, int):
			unicodes = [unicodes]
		for code in unicodes:
			if not isinstance(code, int):
				raise GlifLibError, "unicode values must be int"
			hexCode = hex(code)[2:].upper()
			if len(hexCode) < 4:
				hexCode = "0" * (4 - len(hexCode)) + hexCode
			writer.simpletag("unicode", hex=hexCode)
			writer.newline()

	note = getattr(glyphObject, "note", None)
	if note is not None:
		if not isinstance(note, (str, unicode)):
			raise GlifLibError, "note attribute must be str or unicode"
		note = unicode(note)
		writer.begintag("note")
		writer.newline()
		for line in note.splitlines():
			writer.write(line.strip())
			writer.newline()
		writer.endtag("note")
		writer.newline()

	if drawPointsFunc is not None:
		writer.begintag("outline")
		writer.newline()
		pen = GLIFPointPen(writer)
		drawPointsFunc(pen)
		writer.endtag("outline")
		writer.newline()

	lib = getattr(glyphObject, "lib", None)
	if lib:
		from robofab.plistlib import PlistWriter
		if not isinstance(lib, dict):
			lib = dict(lib)
		writer.begintag("lib")
		writer.newline()
		plistWriter = PlistWriter(aFile, indentLevel=writer.indentlevel,
				indent=writer.indentwhite, writeHeader=False)
		plistWriter.writeValue(lib)
		writer.endtag("lib")
		writer.newline()

	writer.endtag("glyph")
	writer.newline()
	return aFile.getvalue()


# misc helper functions

def buildOutline_Format0(pen, xmlNodes):
	# This reads the "old" .glif format, retroactively named "format 0",
	# later formats have a "format" attribute in the <glyph> element.
	for element, attrs, children in xmlNodes:
		if element == "contour":
			pen.beginPath()
			currentSegmentType = None
			for subElement, attrs, dummy in children:
				if subElement != "point":
					continue
				x = number(attrs["x"])
				y = number(attrs["y"])
				pointType = attrs.get("type", "onCurve")
				if pointType == "bcp":
					currentSegmentType = "curve"
				elif pointType == "offCurve":
					currentSegmentType = "qcurve"
				elif currentSegmentType is None and pointType == "onCurve":
					currentSegmentType = "line"
				if pointType == "onCurve":
					segmentType = currentSegmentType
					currentSegmentType = None
				else:
					segmentType = None
				smooth = attrs.get("smooth") == "yes"
				pen.addPoint((x, y), segmentType=segmentType, smooth=smooth)
			pen.endPath()
		elif element == "component":
			baseGlyphName = attrs["base"]
			transformation = []
			for attr, default in _transformationInfo:
				value = attrs.get(attr)
				if value is None:
					value = default
				else:
					value = number(value)
				transformation.append(value)
			pen.addComponent(baseGlyphName, tuple(transformation))
		elif element == "anchor":
			name, x, y = attrs["name"], number(attrs["x"]), number(attrs["y"])
			pen.beginPath()
			pen.addPoint((x, y), segmentType="move", name=name)
			pen.endPath()


def buildOutline_Format1(pen, xmlNodes):
	for element, attrs, children in xmlNodes:
		if element == "contour":
			pen.beginPath()
			for subElement, attrs, dummy in children:
				if subElement != "point":
					continue
				x = number(attrs["x"])
				y = number(attrs["y"])
				segmentType = attrs.get("type", "offcurve")
				if segmentType == "offcurve":
					segmentType = None
				smooth = attrs.get("smooth") == "yes"
				name = attrs.get("name")
				pen.addPoint((x, y), segmentType=segmentType, smooth=smooth, name=name)
			pen.endPath()
		elif element == "component":
			baseGlyphName = attrs["base"]
			transformation = []
			for attr, default in _transformationInfo:
				value = attrs.get(attr)
				if value is None:
					value = default
				else:
					value = number(value)
				transformation.append(value)
			pen.addComponent(baseGlyphName, tuple(transformation))


_transformationInfo = [
	# field name, default value
	("xScale",    1),
	("xyScale",   0),
	("yxScale",   0),
	("yScale",    1),
	("xOffset",   0),
	("yOffset",   0),
]

class GLIFPointPen(AbstractPointPen):

	"""Helper class using the PointPen protocol to write the <outline>
	part of .glif files.
	"""

	def __init__(self, xmlWriter):
		self.writer = xmlWriter

	def beginPath(self):
		self.writer.begintag("contour")
		self.writer.newline()

	def endPath(self):
		self.writer.endtag("contour")
		self.writer.newline()

	def addPoint(self, pt, segmentType=None, smooth=None, name=None, **kwargs):
		attrs = []
		if pt is not None:
			for coord in pt:
				if not isinstance(coord, (int, float)):
					raise GlifLibError, "coordinates must be int or float"
			attrs.append(("x", str(pt[0])))
			attrs.append(("y", str(pt[1])))
		if segmentType is not None:
			attrs.append(("type", segmentType))
		if smooth:
			attrs.append(("smooth", "yes"))
		if name is not None:
			attrs.append(("name", name))
		self.writer.simpletag("point", attrs)
		self.writer.newline()

	def addComponent(self, glyphName, transformation):
		attrs = [("base", glyphName)]
		for (attr, default), value in zip(_transformationInfo, transformation):
			if not isinstance(value, (int, float)):
				raise GlifLibError, "transformation values must be int or float"
			if value != default:
				attrs.append((attr, str(value)))
		self.writer.simpletag("component", attrs)
		self.writer.newline()


if __name__ == "__main__":
	from pprint import pprint
	from robofab.pens.pointPen import PrintingPointPen
	class TestGlyph: pass
	gs = GlyphSet(".")
	def drawPoints(pen):
		pen.beginPath()
		pen.addPoint((100, 200), name="foo")
		pen.addPoint((200, 250), segmentType="curve", smooth=True)
		pen.endPath()
		pen.addComponent("a", (1, 0, 0, 1, 20, 30))
	glyph = TestGlyph()
	glyph.width = 120
	glyph.unicodes = [1, 2, 3, 43215, 66666]
	glyph.lib = {"a": "b", "c": [1, 2, 3, True]}
	glyph.note = "  hallo!   "
	if 0:
		gs.writeGlyph("a", glyph, drawPoints)
		g2 = TestGlyph()
		gs.readGlyph("a", g2, PrintingPointPen())
		pprint(g2.__dict__)
	else:
		s = writeGlyphToString("a", glyph, drawPoints)
		print s
		g2 = TestGlyph()
		readGlyphFromString(s, g2, PrintingPointPen())
		pprint(g2.__dict__)
