"""

Locate the SysPathExtensions folder in the Python folder,
then sort through the aliases and add the folder paths to sys.path.
For some reason FontLab doesn't load sitecustomise in the Python folder
automatically.
"""



import macfs
import os
import sys

print "Loading SysPathExtensions"

sysPathExtensions = os.path.join(sys.exec_prefix, "SysPathExtensions")



if os.path.exists(sysPathExtensions):
	for aliasFile in os.listdir(sysPathExtensions):
		aliasFile = os.path.join(sysPathExtensions, aliasFile)
		try:
			fss, isFolder, isAlias = macfs.ResolveAliasFile(aliasFile)
		except macfs.error:
			from traceback import print_exc
			print_exc()
			continue
		if isFolder:
			path = fss.as_pathname()
			if path not in sys.path:
				print "Adding", path
				sys.path.append(path)
	
